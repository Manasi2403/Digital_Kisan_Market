package com.blogs.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
public class FarmerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "F_ID")
    private Long id; // Auto-generated Farmer ID

    @ManyToOne
    @JoinColumn(name = "R_ID", foreignKey = @ForeignKey(name = "FK_Farmer_Registration"))
    private RegistrationEntity registration; // Foreign key to Registration Entity

    @Column(name = "F_Name", nullable = false, length = 100)
    private String name; // Farmer's name (foreign key from RegistrationEntity -> R_Name)

    @Column(name = "F_Contact", nullable = false, length = 15)
    private String contact; // Farmer's contact number (foreign key from RegistrationEntity -> R_Mobile_No)

    @Column(name = "F_Product_Name", nullable = false, length = 100)
    private String productName; // Name of the product

    @Column(name = "F_Product_Price", nullable = false)
    private Double productPrice; // Price of the product

    @Column(name = "F_Product_Quantity", nullable = false)
    private Integer productQuantity; // Quantity of the product

    @Column(name = "F_Product_Description", length = 255)
    private String productDescription; // Description of the product

    @Column(name = "F_Seller_Location", nullable = false, length = 100)
    private String sellerLocation; // Seller's location

    @Column(name = "F_Product_Img", length = 255)
    private String productImg; // URL or path to the product image

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RegistrationEntity getRegistration() {
		return registration;
	}

	public void setRegistration(RegistrationEntity registration) {
		this.registration = registration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public Integer getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(Integer productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getSellerLocation() {
		return sellerLocation;
	}

	public void setSellerLocation(String sellerLocation) {
		this.sellerLocation = sellerLocation;
	}

	public String getProductImg() {
		return productImg;
	}

	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}
    
}
