package com.blogs.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
public class RegistrationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "R_ID")
    private Long id;

    @Column(name = "R_Name", nullable = false, length = 100)
    private String name;

    @Column(name = "R_Role", nullable = false, length = 50)
    private String role;

    @Column(name = "R_Mobile_No", nullable = false, length = 15)
    private String mobileNo;

    @Column(name = "R_Email", nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "R_Password", nullable = false, length = 255)
    private String password;
}