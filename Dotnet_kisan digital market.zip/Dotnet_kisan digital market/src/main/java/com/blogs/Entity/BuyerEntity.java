package com.blogs.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class BuyerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "B_ID")
    private Long id; // Auto-generated Buyer ID

    @ManyToOne
    @JoinColumn(name = "R_ID", foreignKey = @ForeignKey(name = "FK_Buyer_Registration"))
    private RegistrationEntity registration; // Foreign key to Registration Entity

    @Column(name = "B_Name", nullable = false, length = 100)
    private String name; // Buyer's name (foreign key from RegistrationEntity -> R_Name)

    @Column(name = "B_Contact", nullable = false, length = 15)
    private String contact; // Buyer's contact number (foreign key from RegistrationEntity -> R_Mobile_No)

    @Column(name = "B_Location", nullable = false, length = 100)
    private String location; // Buyer's location

    @Column(name = "B_Quantity_Required", nullable = false)
    private Integer quantityRequired; // Quantity required by the buyer

    @Column(name = "B_Paid_Price", nullable = false)
    private Double paidPrice; // Price paid by the buyer

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RegistrationEntity getRegistration() {
		return registration;
	}

	public void setRegistration(RegistrationEntity registration) {
		this.registration = registration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getQuantityRequired() {
		return quantityRequired;
	}

	public void setQuantityRequired(Integer quantityRequired) {
		this.quantityRequired = quantityRequired;
	}

	public Double getPaidPrice() {
		return paidPrice;
	}

	public void setPaidPrice(Double paidPrice) {
		this.paidPrice = paidPrice;
	}
    
}
