package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.blogs.Entity.RegistrationEntity;
import java.util.Optional;

public interface RegistrationDao extends JpaRepository<RegistrationEntity, Long> {
    Optional<RegistrationEntity> findByEmail(String email);
}
