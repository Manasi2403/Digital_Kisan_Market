package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blogs.Entity.FarmerEntity;



public interface FarmerDao extends JpaRepository<FarmerEntity, Long> {
    // JpaRepository provides all basic CRUD operations automatically
}
