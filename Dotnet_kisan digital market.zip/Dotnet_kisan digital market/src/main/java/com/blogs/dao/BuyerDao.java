package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blogs.Entity.BuyerEntity;

;

public interface BuyerDao extends JpaRepository<BuyerEntity, Long> {
}
