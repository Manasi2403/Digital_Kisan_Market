package com.blogs.dto;

public class RegistrationApiResponse {

    private String message;

    // Constructor that accepts a String message
    public RegistrationApiResponse(String message) {
        this.message = message;
    }

    // Getter and Setter for message
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}