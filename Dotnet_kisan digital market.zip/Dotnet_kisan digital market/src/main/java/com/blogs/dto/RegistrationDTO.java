package com.blogs.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegistrationDTO {
    private Long id;

    @NotBlank(message = "Name is required.")
    @Size(max = 100, message = "Name must be less than 100 characters.")
    private String name;

    @NotBlank(message = "Role is required.")
    @Size(max = 50, message = "Role must be less than 50 characters.")
    private String role;

    @NotBlank(message = "Mobile number is required.")
    @Size(max = 15, message = "Mobile number must be less than 15 characters.")
    private String mobileNo;

    @NotBlank(message = "Email is required.")
    @Email(message = "Invalid email address.")
    @Size(max = 100, message = "Email must be less than 100 characters.")
    private String email;

    @NotBlank(message = "Password is required.")
    @Size(max = 255, message = "Password must be less than 255 characters.")
    private String password;
}