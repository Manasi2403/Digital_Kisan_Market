package com.blogs.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BuyerDTO {
    private Long Id;              // Buyer ID
    private String Name;          // Buyer Name
    private String Contact;       // Buyer Contact
    private String Location;      // Buyer Location
    private Integer QuantityRequired;  // Quantity Required
    private Double PaidPrice;     // Price Paid
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public Integer getQuantityRequired() {
		return QuantityRequired;
	}
	public void setQuantityRequired(Integer quantityRequired) {
		QuantityRequired = quantityRequired;
	}
	public Double getPaidPrice() {
		return PaidPrice;
	}
	public void setPaidPrice(Double paidPrice) {
		PaidPrice = paidPrice;
	}
	
    
}
