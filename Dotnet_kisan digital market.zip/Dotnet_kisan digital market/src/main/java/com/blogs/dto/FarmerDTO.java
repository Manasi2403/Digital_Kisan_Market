package com.blogs.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class FarmerDTO {
    private Long id;

    @NotBlank(message = "Name is required.")
    @Size(max = 100, message = "Name must be less than 100 characters.")
    private String name;

    @NotBlank(message = "Contact is required.")
    @Size(max = 15, message = "Contact must be less than 15 characters.")
    private String contact;

    @NotBlank(message = "Location is required.")
    @Size(max = 100, message = "Location must be less than 100 characters.")
    private String location;

    @NotBlank(message = "Product is required.")
    @Size(max = 100, message = "Product must be less than 100 characters.")
    private String product;

    @NotNull(message = "Price per unit is required.")
    private Double pricePerUnit;

    @NotNull(message = "Product quantity is required.")
    private Integer productQuantity;

    @Size(max = 255, message = "Product description must be less than 255 characters.")
    private String productDescription;

    @NotBlank(message = "Seller location is required.")
    @Size(max = 100, message = "Seller location must be less than 100 characters.")
    private String sellerLocation;

    @Size(max = 255, message = "Product image URL must be less than 255 characters.")
    private String productImg;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Double getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(Double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public Integer getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(Integer productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getSellerLocation() {
        return sellerLocation;
    }

    public void setSellerLocation(String sellerLocation) {
        this.sellerLocation = sellerLocation;
    }

    public String getProductImg() {
        return productImg;
    }

    public void setProductImg(String productImg) {
        this.productImg = productImg;
    }
}