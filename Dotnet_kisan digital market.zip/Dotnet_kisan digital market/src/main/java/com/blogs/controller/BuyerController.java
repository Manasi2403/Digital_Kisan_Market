package com.blogs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.BuyerDTO;
import com.blogs.service.BuyerService;

@RestController
@RequestMapping("/buyers")
public class BuyerController {

    @Autowired
    private BuyerService buyerService;

    // Constructor
    public BuyerController() {
        System.out.println("in ctor " + getClass());
    }

    // POST request to add a new buyer (location, quantity_required, paid_price)
    @PostMapping("/add")
    public ResponseEntity<?> addBuyer(@RequestBody BuyerDTO buyerDTO) {
        System.out.println("in add new buyer with location, quantity_required, paid_price");

        // Call the service to add the buyer
        ApiResponse response = buyerService.addBuyer(buyerDTO);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
