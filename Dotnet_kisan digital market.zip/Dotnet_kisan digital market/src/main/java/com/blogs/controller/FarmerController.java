package com.blogs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.blogs.dto.FarmerApiResponse;
import com.blogs.dto.FarmerDTO;
import com.blogs.service.FarmerService;

@RestController
@RequestMapping("/farmers")
public class FarmerController {

    @Autowired
    private FarmerService farmerService;

    // Endpoint to add a farmer
    @PostMapping("/add")
    public FarmerApiResponse addFarmer(@RequestBody FarmerDTO farmerDTO) {
        // Calling the service method and returning FarmerApiResponse
        return farmerService.addFarmer(farmerDTO);
    }

    // Endpoint to get all farmers
    @GetMapping("/all")
    public List<FarmerDTO> getAllFarmers() {
        return farmerService.getAllFarmers();
    }

    // Endpoint to get a farmer by ID
    @GetMapping("/{farmerId}")
    public FarmerDTO getFarmerById(@PathVariable Long farmerId) {
        return farmerService.getFarmerById(farmerId);
    }

    // Endpoint to update a farmer's details
    @PutMapping("/update/{farmerId}")
    public FarmerApiResponse updateFarmer(@PathVariable Long farmerId, @RequestBody FarmerDTO farmerDTO) {
        // Calling the service method and returning FarmerApiResponse
        return farmerService.updateFarmer(farmerId, farmerDTO);
    }

    // Endpoint to delete a farmer
    @DeleteMapping("/delete/{farmerId}")
    public FarmerApiResponse deleteFarmer(@PathVariable Long farmerId) {
        // Calling the service method and returning FarmerApiResponse
        return farmerService.deleteFarmer(farmerId);
    }
}
