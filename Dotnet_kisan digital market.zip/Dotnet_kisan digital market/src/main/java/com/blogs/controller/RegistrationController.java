package com.blogs.controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.LoginDTO;
import com.blogs.dto.RegistrationApiResponse;
import com.blogs.dto.RegistrationDTO;
import com.blogs.exception.ResourceNotFoundException;
import com.blogs.Entity.RegistrationEntity;
import com.blogs.service.RegistrationService;
import org.modelmapper.ModelMapper;
import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/registration")
public class RegistrationController {
	

    private final RegistrationService registrationService;
    private final ModelMapper modelMapper;

    public RegistrationController(RegistrationService registrationService, ModelMapper modelMapper) {
        this.registrationService = registrationService;
        this.modelMapper = modelMapper;
    }

    @PostMapping("/register")
    public ResponseEntity<RegistrationApiResponse> register(
            @Valid @RequestBody RegistrationDTO registrationDTO,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors()
                    .stream()
                    .map(error -> error.getField() + ": " + error.getDefaultMessage())
                    .collect(Collectors.toList());

            return ResponseEntity.badRequest()
                    .body(new RegistrationApiResponse("Validation failed: " + String.join(", ", errors)));
        }

        try {
            RegistrationEntity registrationEntity = modelMapper.map(registrationDTO, RegistrationEntity.class);
            ApiResponse response = registrationService.registerUser(registrationEntity);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new RegistrationApiResponse(response.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new RegistrationApiResponse("Registration failed: " + e.getMessage()));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<RegistrationDTO>> getAllUsers() {
        try {
            List<RegistrationEntity> users = registrationService.getAllUsers();
            List<RegistrationDTO> usersDTO = users.stream()
                    .map(user -> modelMapper.map(user, RegistrationDTO.class))
                    .collect(Collectors.toList());

            return ResponseEntity.ok(usersDTO);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<RegistrationDTO> getUserById(@PathVariable Long userId) {
        try {
            RegistrationEntity user = registrationService.getUserById(userId);
            RegistrationDTO userDTO = modelMapper.map(user, RegistrationDTO.class);
            return ResponseEntity.ok(userDTO);
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@Valid @RequestBody LoginDTO loginDTO) {
        try {
            RegistrationEntity user = registrationService.loginUser(loginDTO.getEmail(), loginDTO.getPassword());
            return ResponseEntity.ok(user);
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ApiResponse(e.getMessage(), 401));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse("Login failed", 500));
        }
    }

}