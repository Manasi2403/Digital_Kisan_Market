package com.blogs.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.dao.BuyerDao;
import com.blogs.dto.ApiResponse;
import com.blogs.dto.BuyerDTO;
import com.blogs.Entity.BuyerEntity;

@Service
@Transactional
public class BuyerServiceImpl implements BuyerService {

    @Autowired
    private BuyerDao buyerDao;
    //@Autowired
    //private BuyerDTO buyerdto;

    @Override
    public ApiResponse addBuyer(BuyerDTO buyerdto) {
        BuyerEntity buyerEntity = new BuyerEntity();
        buyerEntity.setName(buyerdto.getName());
        buyerEntity.setContact(buyerdto.getContact());
        buyerEntity.setLocation(buyerdto.getLocation());
        buyerEntity.setQuantityRequired(buyerdto.getQuantityRequired());
        buyerEntity.setPaidPrice(buyerdto.getPaidPrice());
        

        buyerDao.save(buyerEntity);
        return new ApiResponse("Buyer added successfully", 201);
    }

    @Override
    public List<BuyerDTO> getAllBuyers() {
        List<BuyerEntity> buyers = buyerDao.findAll();
        return buyers.stream().map(buyer -> {
            BuyerDTO dto = new BuyerDTO();
            dto.setId(buyer.getId());
            dto.setName(buyer.getName());
            dto.setContact(buyer.getContact());
            dto.setLocation(buyer.getLocation());
            dto.setQuantityRequired(buyer.getQuantityRequired());
            dto.setPaidPrice(buyer.getPaidPrice());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public BuyerDTO getBuyerById(Long buyerId) {
        BuyerEntity buyer = buyerDao.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found with ID: " + buyerId));
        BuyerDTO dto = new BuyerDTO();
        dto.setId(buyer.getId());
        dto.setName(buyer.getName());
        dto.setContact(buyer.getContact());
        dto.setLocation(buyer.getLocation());
        dto.setQuantityRequired(buyer.getQuantityRequired());
        dto.setPaidPrice(buyer.getPaidPrice());
        return dto;
    }

    @Override
    public ApiResponse updateBuyer(Long buyerId, BuyerDTO updatedBuyer) {
        BuyerEntity buyer = buyerDao.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found with ID: " + buyerId));
        buyer.setName(updatedBuyer.getName());
        buyer.setContact(updatedBuyer.getContact());
        buyer.setLocation(updatedBuyer.getLocation());
        buyer.setQuantityRequired(updatedBuyer.getQuantityRequired());
        buyer.setPaidPrice(updatedBuyer.getPaidPrice());

        buyerDao.save(buyer);
        return new ApiResponse("Buyer updated successfully", 200);
    }

    @Override
    public ApiResponse deleteBuyer(Long buyerId) {
        buyerDao.deleteById(buyerId);
        return new ApiResponse("Buyer deleted successfully", 200);
    }
}
