package com.blogs.service;

import java.util.List;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.BuyerDTO;

public interface BuyerService {
    ApiResponse addBuyer(BuyerDTO buyer); // Add buyer using BuyerDTO
    List<BuyerDTO> getAllBuyers(); // Retrieve all buyers
    BuyerDTO getBuyerById(Long buyerId); // Get buyer by ID
    ApiResponse updateBuyer(Long buyerId, BuyerDTO updatedBuyer); // Update buyer details
    ApiResponse deleteBuyer(Long buyerId); // Delete buyer by ID
}
