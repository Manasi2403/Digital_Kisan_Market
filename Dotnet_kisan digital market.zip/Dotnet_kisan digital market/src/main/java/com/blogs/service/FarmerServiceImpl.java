package com.blogs.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.dao.FarmerDao;
import com.blogs.dto.FarmerApiResponse;
import com.blogs.dto.FarmerDTO;
import com.blogs.Entity.FarmerEntity;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor // Lombok annotation to generate a constructor with required fields
public class FarmerServiceImpl implements FarmerService {
	@Autowired

    private  FarmerDao farmerDao; // Lombok will inject this via constructor
	//@Autowired
	//private FarmerDTO farmerDTO;

    @Override
    public FarmerApiResponse addFarmer(FarmerDTO farmerDTO) {
        FarmerEntity farmerEntity = new FarmerEntity();
        farmerEntity.setName(farmerDTO.getName());
        farmerEntity.setContact(farmerDTO.getContact());
        farmerEntity.setProductName(farmerDTO.getProduct());
        farmerEntity.setProductPrice(farmerDTO.getPricePerUnit());
        farmerEntity.setProductQuantity(farmerDTO.getProductQuantity());
        farmerEntity.setProductDescription(farmerDTO.getProductDescription());
        farmerEntity.setSellerLocation(farmerDTO.getSellerLocation());
        farmerEntity.setProductImg(farmerDTO.getProductImg());

        farmerDao.save(farmerEntity);
        return new FarmerApiResponse("Farmer added successfully", 201);
    }

    @Override
    public List<FarmerDTO> getAllFarmers() {
        List<FarmerEntity> farmers = farmerDao.findAll();
        return farmers.stream().map(farmer -> {
            FarmerDTO dto = new FarmerDTO();
            dto.setId(farmer.getId());
            dto.setName(farmer.getName());
            dto.setContact(farmer.getContact());
            dto.setLocation(farmer.getSellerLocation());
            dto.setProduct(farmer.getProductName());
            dto.setPricePerUnit(farmer.getProductPrice());
            dto.setProductQuantity(farmer.getProductQuantity());
            dto.setProductDescription(farmer.getProductDescription());
            dto.setSellerLocation(farmer.getSellerLocation());
            dto.setProductImg(farmer.getProductImg());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public FarmerDTO getFarmerById(Long farmerId) {
        FarmerEntity farmer = farmerDao.findById(farmerId)
                .orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + farmerId));
        FarmerDTO dto = new FarmerDTO();
        dto.setId(farmer.getId());
        dto.setName(farmer.getName());
        dto.setContact(farmer.getContact());
        dto.setLocation(farmer.getSellerLocation());
        dto.setProduct(farmer.getProductName());
        dto.setPricePerUnit(farmer.getProductPrice());
        dto.setProductQuantity(farmer.getProductQuantity());
        dto.setProductDescription(farmer.getProductDescription());
        dto.setSellerLocation(farmer.getSellerLocation());
        dto.setProductImg(farmer.getProductImg());
        return dto;
    }

    @Override
    public FarmerApiResponse deleteFarmer(Long farmerId) {
        FarmerEntity farmer = farmerDao.findById(farmerId)
                .orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + farmerId));
        farmerDao.delete(farmer);
        return new FarmerApiResponse("Farmer deleted successfully", 200);
    }

    @Override
    public FarmerApiResponse updateFarmer(Long farmerId, FarmerDTO farmerDTO) {
        FarmerEntity farmer = farmerDao.findById(farmerId)
                .orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + farmerId));
        
        farmer.setName(farmerDTO.getName());
        farmer.setContact(farmerDTO.getContact());
        farmer.setProductName(farmerDTO.getProduct());
        farmer.setProductPrice(farmerDTO.getPricePerUnit());
        farmer.setProductQuantity(farmerDTO.getProductQuantity());
        farmer.setProductDescription(farmerDTO.getProductDescription());
        farmer.setSellerLocation(farmerDTO.getSellerLocation());
        farmer.setProductImg(farmerDTO.getProductImg());
        
        farmerDao.save(farmer);
        return new FarmerApiResponse("Farmer updated successfully", 200);
    }
}