package com.blogs.service;

import java.util.List;

import com.blogs.dto.FarmerApiResponse;
import com.blogs.dto.FarmerDTO;

public interface FarmerService {
    FarmerApiResponse addFarmer(FarmerDTO farmer); // Add farmer using FarmerDTO
    List<FarmerDTO> getAllFarmers(); // Retrieve all farmers
    FarmerDTO getFarmerById(Long farmerId); // Get farmer by ID
    FarmerApiResponse updateFarmer(Long farmerId, FarmerDTO updatedFarmer); // Update farmer details
    FarmerApiResponse deleteFarmer(Long farmerId); // Delete farmer by ID
}
