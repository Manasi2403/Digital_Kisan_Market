package com.blogs.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.blogs.dao.RegistrationDao;
import com.blogs.dto.ApiResponse;
import com.blogs.exception.ResourceNotFoundException;
import com.blogs.Entity.RegistrationEntity;

@Service
public class RegistrationServiceImpl implements RegistrationService {

    private final RegistrationDao registrationDao;

    public RegistrationServiceImpl(RegistrationDao registrationDao) {
        this.registrationDao = registrationDao;
    }

    @Override
    public ApiResponse registerUser(RegistrationEntity registrationEntity) {
        registrationDao.save(registrationEntity);
        return new ApiResponse("User registered successfully", 201);
    }

    @Override
    public List<RegistrationEntity> getAllUsers() {
        return registrationDao.findAll();
    }

    @Override
    public RegistrationEntity getUserById(Long userId) {
        return registrationDao.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));
    }

    @Override
    public RegistrationEntity loginUser(String email, String password) {
        Optional<RegistrationEntity> userOptional = registrationDao.findByEmail(email);
        if (userOptional.isPresent()) {
            RegistrationEntity user = userOptional.get();
            if (user.getPassword().equals(password)) {  // In real-world, use password hashing
                return user;
            } else {
                throw new ResourceNotFoundException("Invalid password.");
            }
        } else {
            throw new ResourceNotFoundException("User not found with this email.");
        }
    }
}
