package com.blogs.service;

import com.blogs.dto.ApiResponse;
import com.blogs.Entity.RegistrationEntity;
import java.util.List;

public interface RegistrationService {
    ApiResponse registerUser(RegistrationEntity registrationEntity);
    List<RegistrationEntity> getAllUsers();
    RegistrationEntity getUserById(Long userId);
    RegistrationEntity loginUser(String email, String password);
}
